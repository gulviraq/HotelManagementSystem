
import java.util.Scanner;

public class HotelManagementSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("==========================================");
        System.out.println("       HOTEL MANAGEMENT SYSTEM");
        System.out.println("       СИСТЕМА УПРАВЛЕНИЯ ГОСТИНИЦЕЙ");
        System.out.println("==========================================");

        // БЛОК 1. ИНФОРМАЦИЯ О ГОСТИНИЦЕ

        System.out.println("\n--- ИНФОРМАЦИЯ О ГОСТИНИЦЕ ---");

        String hotelName;
        String hotelAddress;
        String hotelPhone;
        int totalRooms;
        int availableRooms;
        float hotelRating;
        char hotelCategory;
        boolean isOpen;

        System.out.print("Название гостиницы: ");
        hotelName = sc.nextLine();

        System.out.print("Адрес гостиницы: ");
        hotelAddress = sc.nextLine();

        System.out.print("Телефон гостиницы: ");
        hotelPhone = sc.nextLine();

        System.out.print("Общее количество номеров: ");
        totalRooms = Integer.parseInt(sc.nextLine());

        System.out.print("Количество свободных номеров: ");
        availableRooms = Integer.parseInt(sc.nextLine());

        System.out.print("Рейтинг гостиницы: ");
        hotelRating = Float.parseFloat(sc.nextLine().replace(',', '.'));

        System.out.print("Категория гостиницы (A/B/C): ");
        hotelCategory = sc.next().charAt(0);

        System.out.print("Гостиница работает? (true/false): ");
        isOpen = sc.nextBoolean();

        // БЛОК 2. ИНФОРМАЦИЯ О КЛИЕНТЕ

        sc.nextLine();

        System.out.println("\n--- ИНФОРМАЦИЯ О КЛИЕНТЕ ---");

        String clientName;
        int clientAge;
        String clientPassport;
        String clientPhone;
        double clientBalance;
        boolean isRegistered;

        System.out.print("ФИО клиента: ");
        clientName = sc.nextLine();

        System.out.print("Возраст клиента: ");
        clientAge = sc.nextInt();

        sc.nextLine();

        System.out.print("Номер документа (тестовые данные): ");
        clientPassport = sc.nextLine();

        System.out.print("Телефон клиента: ");
        clientPhone = sc.nextLine();

        System.out.print("Баланс клиента: ");
        clientBalance = sc.nextDouble();

        System.out.print("Клиент зарегистрирован? (true/false): ");
        isRegistered = sc.nextBoolean();

        // БЛОК 3. ИНФОРМАЦИЯ О НОМЕРЕ

        System.out.println("\n--- ИНФОРМАЦИЯ О НОМЕРЕ ---");

        int roomNumber;
        String roomType;
        double roomPrice;
        int roomFloor;
        boolean hasWiFi;
        int bedCount;
        char roomStatus;

        System.out.print("Номер комнаты: ");
        roomNumber = sc.nextInt();

        sc.nextLine();

        System.out.print("Тип номера (Standard/Deluxe/Lux): ");
        roomType = sc.nextLine();

        System.out.print("Цена за сутки: ");
        roomPrice = sc.nextDouble();

        System.out.print("Этаж: ");
        roomFloor = sc.nextInt();

        System.out.print("Есть Wi-Fi? (true/false): ");
        hasWiFi = sc.nextBoolean();

        System.out.print("Количество кроватей: ");
        bedCount = sc.nextInt();

        System.out.print("Статус номера (F - свободен, B - занят): ");
        roomStatus = sc.next().charAt(0);

        // БЛОК 4. БРОНИРОВАНИЕ И ФИНАНСЫ

        System.out.println("\n--- БРОНИРОВАНИЕ И ОПЛАТА ---");

        int daysOfStay;

        System.out.print("Количество дней проживания: ");
        daysOfStay = sc.nextInt();

        double fullCost = roomPrice * daysOfStay;

        System.out.println("Стоимость без скидки: " + fullCost + " тг");

        double discount;

        System.out.print("Размер скидки (%): ");
        discount = sc.nextDouble();

        double discountAmount = fullCost * discount / 100;

        double finalCost = fullCost - discountAmount;

        System.out.println("Сумма скидки: " + discountAmount + " тг");
        System.out.println("Итоговая стоимость: " + finalCost + " тг");

        double paymentAmount;

        System.out.print("Внесённая оплата: ");
        paymentAmount = sc.nextDouble();

        double debt = Math.max(0, finalCost - paymentAmount);
        double overpayment = Math.max(0, paymentAmount - finalCost);

        // ИДЕНТИФИКАТОР БРОНИРОВАНИЯ

        long bookingId = System.currentTimeMillis();

        // ПРОВЕРКА БРОНИРОВАНИЯ

        boolean roomAvailable = roomStatus == 'F'
                || roomStatus == 'f';

        boolean canBook = isOpen
                && isRegistered
                && roomAvailable
                && availableRooms > 0;

        String bookingStatus;

        if (!isOpen) {
            bookingStatus = "Гостиница закрыта";
        } else if (!isRegistered) {
            bookingStatus = "Клиент не зарегистрирован";
        } else if (!roomAvailable || availableRooms <= 0) {
            bookingStatus = "Номер занят или свободных номеров нет";
        } else if (debt > 0) {
            bookingStatus = "Бронирование подтверждено, ожидается доплата";
        } else {
            bookingStatus = "Бронирование подтверждено, оплачено полностью";
        }

        // БЛОК 5. ИТОГОВЫЙ ОТЧЁТ

        System.out.println("\n\n");
        System.out.println("==========================================");
        System.out.println("          ОТЧЁТ О БРОНИРОВАНИИ");
        System.out.println("==========================================");

        System.out.println("\n--- ГОСТИНИЦА ---");

        System.out.println("Название: " + hotelName);
        System.out.println("Адрес: " + hotelAddress);
        System.out.println("Телефон: " + hotelPhone);
        System.out.println("Всего номеров: " + totalRooms);
        System.out.println("Свободных номеров: " + availableRooms);
        System.out.println("Рейтинг: " + hotelRating);
        System.out.println("Категория: " + hotelCategory);
        System.out.println("Работает: " + isOpen);

        System.out.println("\n--- КЛИЕНТ ---");

        System.out.println("ФИО: " + clientName);
        System.out.println("Возраст: " + clientAge);
        System.out.println("Документ: " + clientPassport);
        System.out.println("Телефон: " + clientPhone);
        System.out.println("Баланс: " + clientBalance);
        System.out.println("Регистрация: " + isRegistered);

        System.out.println("\n--- НОМЕР ---");

        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Тип номера: " + roomType);
        System.out.println("Цена за сутки: " + roomPrice + " тг");
        System.out.println("Этаж: " + roomFloor);
        System.out.println("Wi-Fi: " + hasWiFi);
        System.out.println("Количество кроватей: " + bedCount);
        System.out.println("Статус номера: " + roomStatus);

        System.out.println("\n--- ФИНАНСОВЫЙ ОТЧЁТ ---");

        System.out.println("ID бронирования: " + bookingId);
        System.out.println("Дней проживания: " + daysOfStay);
        System.out.println("Стоимость проживания: " + fullCost + " тг");
        System.out.println("Скидка: " + discount + "%");
        System.out.println("Сумма скидки: " + discountAmount + " тг");
        System.out.println("Итоговая сумма: " + finalCost + " тг");
        System.out.println("Внесённая оплата: " + paymentAmount + " тг");
        System.out.println("Остаток задолженности: " + debt + " тг");

        if (overpayment > 0) {
            System.out.println("Переплата: " + overpayment + " тг");
        }

        System.out.println("\n--- СТАТУС БРОНИРОВАНИЯ ---");

        System.out.println(bookingStatus);

        System.out.println("\n==========================================");
        System.out.println("       ПРОГРАММА ЗАВЕРШЕНА");
        System.out.println("==========================================");

        sc.close();
    }
}
